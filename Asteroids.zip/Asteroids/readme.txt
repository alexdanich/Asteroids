##NEO Earth Close Approaches

#Close Approach Data
 
The following table shows close approaches to the Earth by near-Earth objects (NEOs) limited as selected in the �Table Settings� below. 
Data are not available prior to 1900 A.D nor after 2200 A.D. Data are further limited to encounters with reasonably low uncertainty

LD-	Lunar distance (LD or ? ? L     {\textstyle \Delta _{\oplus L}}  {\textstyle \Delta _{\oplus L}}), also called Earth�Moon distance, 
	Earth�Moon characteristic distance, or distance to the Moon, is a unit of measure in astronomy. It is the average distance from the center 
	of Earth to the center of the Moon. More technically, it is the mean semi-major axis of the geocentric lunar orbit. It may also refer to the 
	time-averaged distance between the centers of the Earth and the Moon, or less commonly, the instantaneous Earth�Moon distance. 
	The lunar distance is approximately a quarter of a million miles (400000 km).
CA- Close Approach distance

V- relative(km/s)
V-infinity(km/s)
H- implais for larger asteroids diameter
Close-Approach(CA) date-
Object-name of asteroid
AU-The astronomical unit (symbol: au,[1][2][3] ua,[4] or AU) is a unit of length, roughly the distance from Earth to the Sun.
PHA-
Palermo scale
Torino scale


#Removed Objects
  
As the set of available observations for a given object grows we are often able torule out previous potential impacts as no longer consistent
 with the observations.The following table gives a listing (in reverse chronological order) of such objectsfor which all previously detected
 potential impacts have been eliminated. 

#NEA orbits and close approach tables are continuously and automatically updated whenever new observations are made available, generally within
 a couple of hours of the release of the information. Whenever an NEA orbit is updated the object is re-prioritized and, if appropriate, it is 
re-queued for a new potential impact search. This process is ongoing - taking place anytime, day and night, seven days a week.

Because orbits stemming from very limited observation sets are more uncertain it is more likely that such orbits will "permit" future impacts. 
However, such early predictions can often be ruled out as we incorporate more observations and reduce the uncertainties in the object's orbit. 
Most often, the threat associated with a specific object will decrease as additional observations become available, and so objects will be 
posted to, and later removed from, our Impact Risk Page. The Palermo Scale values will typically start out at less negative values when the 
object's orbit is most uncertain and evolve to more negative values (and eventually off the list) as more and more observations allow the 
object's orbit to be continually improved.

On the other hand, in the unlikely case where a particular potential impact event persists until the orbit is relatively well constrained, the impact probability and associated risk will tend to increase as observations are added. This is not too paradoxical: If an asteroid is indeed going to come very near the Earth then a collision cannot be ruled out early on. The impact probability will tend to grow as the orbit is refined and alternative and safer trajectories are eliminated. Eventually, the impact probability will drop (usually quite abruptly) to zero or, if the asteroid is really on a collision trajectory, it will continue to grow until it reaches 100%.
