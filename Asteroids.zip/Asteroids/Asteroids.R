# 0: Load the data in RStudio
## Set working directory to Springboard  
setwd("~/Capstone Project Proposal/Asteroids") 

asteroids <- read.csv("asteroids_data.csv")
head(asteroids)
View(asteroids)
asteroids<-data.frame(lapply(asteroids,as.numeric))
library(dplyr)
library(tidyr)
library(data.table)
#2: Separate and cleaning
str(asteroids)
asteroids<- separate(asteroids, Close.Approach..CA..Date, c("year","month", "day","restdate"), sep="-")

asteroids<- separate(asteroids, day, c("day", "dayrest"), sep=" ")
asteroids<- separate(asteroids, dayrest, c("minutes", "minutesrest"), sep="�")
asteroids<-asteroids[,-6]
asteroids<-asteroids[,-6]
asteroids1<-separate(asteroids, CA.Distance.Nominal..LD...au., c("Moondist_LD_nom", "Solardist_AU_max"), sep=" ")
asteroids1<-separate(asteroids1, CA.Distance.Minimum..LD...au., c("Moondist_LD_min", "Solardist_AU_min"), sep=" ")
asteroids1<-asteroids1[,-7]
asteroids1<-asteroids1[,-8]
#Separate and fill NA with zeros
asteroids1[is.na(asteroids1)]<-0
asteroids1<-separate(asteroids1, Estimated.Diameter, c("Diam_min_m", "Diam_max_m"), sep=" - ")
asteroids1<-separate(asteroids1, Diam_min_m, c("Diam_min", "min_m"), sep=" ")
asteroids1<-asteroids1[,-12]
asteroids2<-unite(asteroids1, Date, day, month, year, sep="-")
#cut to 1000 row
asteroids2<-asteroids2[1:1000,]
#change column names for speed
colnames(asteroids2)[colnames(asteroids2)=="V.relative..km.s."] <- "Speed_kms"
#delete max speed column
asteroids2<-asteroids2[,-7]
asteroids2<-asteroids2[,-9]
asteroids2<-asteroids2[,-9]
#select columns charater and transform them in numeric like Diam_min
select_data<-select(asteroids2, Diam_min)
select_data<-data.frame(lapply(select_data,as.umeric))
select_data1<-select(asteroids2, Moondist_LD_nom)
select_data1<-data.frame(lapply(select_data1,as.numeric))

#delet old column
asteroids2<-asteroids2[,-8]
asteroids2<-asteroids2[,-4]
# bind new column back with numeric values
asteroids2<-bind_cols(asteroids2, select_data)
asteroids2<-bind_cols(asteroids2, select_data1)
write.csv(asteroids2, "asteroids_clean.csv")

##Now the data is ready we can play with it using ggplot2
asteroids_clean <- read.csv("asteroids_clean.csv")


